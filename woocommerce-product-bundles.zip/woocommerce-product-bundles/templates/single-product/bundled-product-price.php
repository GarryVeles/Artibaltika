<?php
/**
 * Bundled Product Price
 */

?>
<p itemprop="price" class="price"><?php echo $product->get_price_html(); ?></p>